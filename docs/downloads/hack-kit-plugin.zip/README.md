# Hack Kit 1.4.0: portable plugin

**Think deeper. Challenge harder. Build smarter.** Full docs: https://github.com/syed-imadulla/hack-kit

This package works in ChatGPT, Codex and Google Antigravity (and any agent that reads `skills/*/SKILL.md`).

## ChatGPT
Plugins → Add → New Plugin → choose `hack-kit-plugin.zip` → Add plugin. Then start a chat and say **"hack start"**.

## Codex
Unzip into a folder and add it to a marketplace file (`~/.agents/plugins/marketplace.json`), then install it from the Plugins directory.

## Antigravity
- **IDE / App, one project:** copy `skills/hack-kit/` into `<your project>/.agents/skills/hack-kit/`.
- **IDE / App, every project:** copy `skills/hack-kit/` into `~/.gemini/config/skills/hack-kit/`.
- **As a plugin:** unzip into `~/.gemini/config/plugins/hack-kit/` (or `.agents/plugins/hack-kit/` in a project).
- **CLI:** `agy plugin install ./hack-kit` (the unzipped folder).

Then ask the agent: **"hack start"** (or type `/hack-kit` where slash commands are supported).
Antigravity can run commands, so it uses the scripts in `skills/hack-kit/scripts/` (Python 3) for vote counting, plan checks and the final PDF.

## What's different from the Claude Code plugin
Phases are said in words ("hack ideate") instead of `/hack:` commands. If your tool can't run separate subagents, the jury is simulated in one conversation, which is less independent.
